﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MySql.Data.MySqlClient;
using NS_Task.Models;
using NS_Task.Repositories;

namespace NS_Task.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PersonController : Controller
    {
        IPersonRepository _personRepository;
        public PersonController(IPersonRepository personRepository)
        {
            _personRepository = personRepository;
        }

        [HttpGet("getall")]
        public async Task<IActionResult> Get()
        {
            List<Person> person = await _personRepository.GetAllAsync();
            return this.Ok(person);
        }

        [HttpPost("create")]
        public async Task<IActionResult> Post(Person person)
        {
            _personRepository.CreateAsync(person);
            return this.Ok(person);
        }

        [HttpPut("update")]
        public async Task<IActionResult> Put(Person person)
        {
            _personRepository.UpdateAsync(person);
            return this.Ok(person);
        }

        [HttpDelete("delete")]
        public async Task<IActionResult> Delete(Person person)
        {
            _personRepository.DeleteAsync(person);
            return this.Ok(person);
        }
    }
}
