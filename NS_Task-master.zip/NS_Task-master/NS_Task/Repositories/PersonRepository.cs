﻿using Microsoft.EntityFrameworkCore;
using MySql.Data.MySqlClient;
using NS_Task.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NS_Task.Repositories
{
    public class PersonRepository : IPersonRepository
    {
        private readonly AppDbContext db;
        public PersonRepository(AppDbContext db)
        {
            this.db = db;
        }

        public Task<List<Person>> GetAllAsync()
        {
            return db.Persons.ToListAsync();
        }

        public async void CreateAsync(Person person)
        {
            if (person == null)
            {
                throw new ArgumentNullException("person");
            }

            await db.AddAsync(person);
            await db.SaveChangesAsync();
        }

        public async void DeleteAsync(Person person)
        {
            if (person == null)
            {
                throw new ArgumentNullException("person");
            }

            db.Remove(person);
            await db.SaveChangesAsync();
        }

        public async void UpdateAsync(Person person)
        {
            if (person == null)
            {
                throw new ArgumentNullException("person");
            }

            db.Update(person);
            await db.SaveChangesAsync();
        }
    }
}
