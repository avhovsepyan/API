﻿using NS_Task.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NS_Task.Repositories
{
    public interface IPersonRepository
    {
        Task<List<Person>> GetAllAsync();
        void CreateAsync(Person entity);
        void UpdateAsync(Person entity);
        void DeleteAsync(Person entity);
    }
}
